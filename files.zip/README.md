# The Victoverse Press — Project Tracker

A production tracker for **Unleash Your Inner Blueprint** by Adam Romans, published under The Victoverse Press.

## Features

- ✅ **Persistent progress** — task states and notes save automatically in your browser
- 📝 **Notes on tasks** — click the pencil icon on any task to add a note
- ⏳ **Countdown to key dates** — days remaining to the Raquel call and manuscript return
- 🖨️ **Print view** — clean printable layout with notes visible
- 📄 **Export** — download a plain text summary of all tasks and notes
- 🌓 **Dark / light mode** — toggle and your preference is saved

## Live App

Hosted via GitHub Pages: `https://[your-username].github.io/victoverse-tracker/`

## Usage

Open `index.html` in any browser — no build step, no dependencies, no server needed. Everything runs client-side.

## Structure

\`\`\`
victoverse-tracker/
└── index.html    ← the entire app
\`\`\`

## Phases tracked

1. Editorial
2. Design
3. Illustration
4. Publishing & Legal
5. Website & Digital
6. Content Recording
7. The Blueprint Collective
8. Launch
